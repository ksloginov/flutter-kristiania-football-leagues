package no.kristiania.fotmob

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
