class League {
  int id;
  String name;
  League(this.id, this.name);
}